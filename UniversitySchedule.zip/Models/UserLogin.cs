﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversitySchedule.Models
{
    public class UserLogin
    {
        public static User? User { get; set; }
    }
}
